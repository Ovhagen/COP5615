defmodule Proj3.ChordNodeTest do
  use ExUnit.Case
  doctest Proj3

  setup do

  end

  test ""

end
