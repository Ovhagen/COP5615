defmodule Proj3 do
  @moduledoc """
  Documentation for Proj3.
  """

  @doc """
  Hello world.
  """
  def hello do
    :world
  end
end
