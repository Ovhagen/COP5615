defmodule Proj3Test do
  use ExUnit.Case
  doctest Proj3

  test "greets the world" do
    assert Proj3.hello() == :world
  end
end
