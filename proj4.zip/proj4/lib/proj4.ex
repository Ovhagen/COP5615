defmodule Proj4 do
  @moduledoc """
  Documentation for Proj4.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Proj4.hello()
      :world

  """
  def hello do
    :world
  end
end
