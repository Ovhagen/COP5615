defmodule Proj2Test do
  use ExUnit.Case
  doctest Proj2

end
